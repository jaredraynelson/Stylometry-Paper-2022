# import pandas as pd
import nltk
nltk.download('averaged_perceptron_tagger')

# verbs = {}
# adverbs = {}
# adjectives = {}
# characters = {}
# nouns = {}



# def get_verbs():
#     global verbs
#     df = pd.read_csv('verb_data.csv')
#     arr = df.to_numpy()
#     lyst = arr.flatten()
#     verbs = list(lyst)
#     verbs = [x for x in verbs if (str(x) != 'nan') and (str(x)!= '-')]
    
# def get_adverbs():
#     global adverbs
#     df = pd.read_csv('adverb_data.csv')
#     arr = df.to_numpy()
#     lyst = arr.flatten()
#     adverbs = list(lyst)
#     adverbs = [x for x in adverbs if (str(x) != 'nan') and (str(x)!= '-')]
    
# def get_adjectives():
#     global adjectives
#     df = pd.read_csv('adjective_data.csv')
#     arr = df.to_numpy()
#     lyst = arr.flatten()
#     adjectives = list(lyst)
#     adjectives = [x for x in adjectives if (str(x) != 'nan') and (str(x)!= '-')]


class Read():
    # global verbs
    # global adverbs
    # global adjectives
    # global nouns
    # global characters
    
    '''
    Pass in the .txt file to be read.
    Outputs
    '''
    words = {}
    
    def __init__(self, file, n):
        self.n = n
        self.verbs = {}
        self.adverbs = {}
        self.adjectives = {}
        self.nouns = {}
        self.characters = {}
        self.n_grams = {}
        self.lyst = self.read_vals(file)
        self.word_ave, self.sentence_count, self.comma_count, self.apos, self.dash_count = self.sentence_info()                                   #

        
        
        
        
    def __str__(self):
        string = ''
        for i in self.lyst:
            string += i + '\n'
        return string

    def read_vals(self, file):
        lyst = []
        
        with open(file, 'r', encoding='utf8') as text:                 
            for line in text:
                # line=line.lower()
                line=line.strip()
                line += ' ' 
                lyst.append(line)
        return lyst
    
    
    def get_ngrams(self, lyst):
        # lyst = string.split()
        k = self.n-1
        start = 0
        
        while k < len(lyst):
            string = ''
            for i in range(start, k+1):
                string+=lyst[i]+' '
            
            k+=1
            start+=1
            if string not in self.n_grams.keys():
                self.n_grams[string] = 1
            else:
                self.n_grams[string] += 1
            
        

    def sentence_info(self):
        unwanted = ['"' , '.' , '?' , '!' , ';' , ':' , ',' , ' ', '-', '(', ')', '--','“','”','‘','’']
        count_word = 0
        count_sentence = 0
        count_comma = 0
        count_apos = 0
        count_dash = 0
        
        for i in self.lyst: # Look at the words,
            
             wordLyst = []  
             
             word_separated = i.split()
             for k in word_separated:
                
                jay = k.replace('"', '') 
                jay = ''.join(t for t in jay if not t in unwanted)
                if jay == '':
                    pass
                else:
                    wordLyst.append(jay)
                    
                
                
             q = nltk.pos_tag(wordLyst)         #RETURNS A TUPLE
             self.get_ngrams(wordLyst)
             for rtrnType in q:
                 if rtrnType[1][0:2] == 'NN':
                     if rtrnType[0] in self.nouns:
                         self.nouns[rtrnType[0]] +=1
                     else:
                         self.nouns[rtrnType[0]] = 1
                 elif rtrnType[1][0:2] == 'RB':
                     if rtrnType[0] in self.adverbs:
                         self.adverbs[rtrnType[0]] +=1
                     else:
                        self.adverbs[rtrnType[0]] = 1
                 elif rtrnType[1][0:2] == 'JJ':
                     if rtrnType[0] in self.adjectives:
                         self.adjectives[rtrnType[0]] +=1
                     else:
                         self.adjectives[rtrnType[0]] = 1
                 elif rtrnType[1][0:2] == 'VB':
                     if rtrnType[0] in self.verbs:
                         self.verbs[rtrnType[0]] +=1
                     else:
                         self.verbs[rtrnType[0]] = 1
                        
             for j in i.split():
                count_word += 1
                
                r = j.strip().strip(',').strip('.').strip('?').strip('!').strip('--').strip(':').strip(';').lower()
                
                
                
                if r not in self.words: # create a bank of words used.
                    self.words[r]= 1
                else:
                    self.words[r] += 1
            
             for k in i: # Look at the letters
                # Look for punctuation '!' = 21, '?' = 63, '.' = 46, ',' = 44, ''' = 39, '-' = 45
                if k not in self.characters:
                    self.characters[k] = 1
                else:
                    self.characters[k] += 1
                ord_val = ord(k) 
                if ord_val == 21:
                    count_sentence += 1
                elif ord_val == 63:
                    count_sentence += 1
                elif ord_val == 46:
                    count_sentence += 1
                elif ord_val == 44: 
                    count_comma += 1
                elif ord_val == 8217 or ord_val == 39:
                    count_apos += 1
                elif ord_val == 45:
                    count_dash += 1
                else:
                    pass
        ave_word = count_word/count_sentence
        return ave_word, count_sentence, count_comma, count_apos, count_dash

                    
                
# get_verbs()                
# get_adverbs()  
# get_adjectives()            
            


