# -*- coding: utf-8 -*-
"""
Created on Sat Apr 17 16:41:58 2021

@author: Jared
"""

import nltk
nltk.download('averaged_perceptron_tagger')

lyst = []

text = "Hello my name is Jeremy. I'm doing well. How are you today? The sky is blue."
text = text.split()
for i in text:
    # print(i)
    # x = i.lower()
    x = i.strip(',')
    x = x.strip('.')
    x = x.strip('!')
    x = x.strip('?')
    lyst.append(x)

# print(lyst)
q = nltk.pos_tag(lyst)

# w = ['Jack']
# print(nltk.pos_tag(w))

print(q)

noun = []
adverb = []
verb = []
adjective = []
for i in q:
    if i[1][0:2] == 'NN':
        noun.append(i[0])
    elif i[1][0:2] == 'RB':
        adverb.append(i[0])
    elif i[1][0:2] == 'JJ':
        adjective.append(i[0])
    elif i[1][0:2] == 'VB':
        verb.append(i[0])
        
        

print('Nouns:\n', noun)
print('Verbs\n', verb)
print('Adjectives\n',adjective)
print('Adverbs', adverb)

    