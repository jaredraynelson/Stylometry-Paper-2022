# -*- coding: utf-8 -*-
"""
Created on Mon May  3 11:25:42 2021

@author: Jared
"""

import text_info as ti
import math

ngrams_vals = 0
comp_vals = 0

def comp(first, second, _type = 'noun'):
    global comp_vals
    comp_eqn = 100*abs((first-second)/first)
    # If the value is greater, then add 1.
    if comp_eqn<5:
        comp_vals+=2
        print('\nThere is very high correlation with the ' + _type + ' usage!\n')
        
    elif comp_eqn<10:
        comp_vals+=1.5
        print('\nThere is high correlation with the ' + _type + ' usage!\n')
        
    elif comp_eqn<15:
        comp_vals += 1
        print('\nThere is correlation with the ' + _type + ' usage!\n')
        
    elif comp_eqn<20:
        comp_vals += 0.5
        print('\nThere is little correlation with the ' + _type + ' usage!\n')
        
    elif comp_eqn>50:
        print('\nThere is negative correlation with the ' + _type + ' usage!\n')
        comp_vals -= 3
        
    elif comp_eqn>40:
        print('\nThere is no correlation with the ' + _type + ' usage!\n')
        comp_vals -= 2
        
    else:
        print('\nThere is no correlation with the ' + _type + ' usage!\n')
        comp_vals -= 1
        
    
def comp_ngrams(dict1, dict2, n):
    '''
    Takes in two dictionaries which come from text_info.py and will perform
    calculations to determine whether there is correlation in the n_grams of
    the words.
    '''
    global ngrams_vals
    cost = 15*math.exp(-2.708*(n-2))
    
    sum1 = sum(dict1.values())
    sum2 = sum(dict2.values())
    tot = 0
    # iterate through one dictionary and find the same string in the other.
    for i in dict1.keys():     
        if i in dict2.keys():
            x = dict1[i]
            y = dict2[i]
            # if equal, then sum up the two values.
            tot += x+y
    pred = 100*(tot/(sum1+sum2))
    # Compare the values to the cost function.
    if  pred >= 1.5*cost:
        ngrams_vals+=4
        return pred, "Using NGrams, this data has very strong correlation."
    elif pred >= 1.5*cost:
        ngrams_vals+=3
        return pred, "Using NGrams, this data has strong correlation."
    elif pred >= cost:
        ngrams_vals+=2
        return pred, "Using NGrams, this data has correlation."
    elif pred <= 0.5*cost:
        ngrams_vals-=3
        return pred, "Using NGrams, this data has absolutely no correlation."    
    elif pred <= 0.75*cost:
        ngrams_vals-=2
        return pred, "Using NGrams, this data has no correlation."
    else:
        ngrams_vals-=1
        return pred, "Using NGrams, this data doesn\'t have enough correlation." 

def main():
    # txt1 = input('Please enter in the filename here.\n')
    # txt2 = input('Please enter the second filename here.\n')
    pred_lyst = []
    txt1 = 'moby_train.txt'
    authors = ['moby_test','kidnapped_train','kidnapped_test','alice_train','alice_test','treasure_island_test']
    for author in authors:
        global comp_vals
        global ngrams_vals
        comp_vals = 0
        ngrams_vals = 0
        txt2 = author+'.txt'
        print('\n\nANALYSIS OF '+txt1+' & '+txt2 + ':\n')
        
        n_gram = [2,3,4]
        
        for i in n_gram:
            ex2 = ti.Read(txt2, i)
            ex1 = ti.Read(txt1, i)
            
            ex1_ngrams = ex1.n_grams
            sorted_ex1_ngrams = {}
            sorted_keys = sorted(ex1_ngrams, key=ex1_ngrams.get)  # [1, 3, 2]
        
            for w in sorted_keys:
                sorted_ex1_ngrams[w] = ex1_ngrams[w]
        
            
                
            ex2_ngrams = ex2.n_grams
            sorted_ex2_ngrams = {}
            sorted_keys = sorted(ex2_ngrams, key=ex2_ngrams.get)  # [1, 3, 2]
        
            for w in sorted_keys:
                sorted_ex2_ngrams[w] = ex2_ngrams[w]
        
            
        
            sorted_ex1_ngrams = {k: v / total for total in (sum(sorted_ex1_ngrams.values()),) for k, v in sorted_ex1_ngrams.items()}
            sorted_ex2_ngrams = {k: v / total for total in (sum(sorted_ex2_ngrams.values()),) for k, v in sorted_ex2_ngrams.items()}
        
    
            
            
            pred, x = comp_ngrams(sorted_ex1_ngrams, sorted_ex2_ngrams, i)
            
            print(x)
            pred_lyst.append(pred)
            
        comp(ex1.apos/ex1.sentence_count, ex2.apos/ex2.sentence_count, _type = 'apostrophe')
        print(ex1.apos/ex1.sentence_count, ex2.apos/ex2.sentence_count)
        comp(sum(ex1.adjectives.values())/ex1.sentence_count, sum(ex2.adjectives.values())/ex2.sentence_count, _type = 'adjective')
        print(sum(ex1.adjectives.values())/ex1.sentence_count, sum(ex2.adjectives.values())/ex2.sentence_count)
        comp(sum(ex1.adverbs.values())/ex1.sentence_count, sum(ex2.adverbs.values())/ex2.sentence_count, _type = 'adverb')
        print(sum(ex1.adverbs.values())/ex1.sentence_count, sum(ex2.adverbs.values())/ex2.sentence_count)
        comp(sum(ex1.verbs.values())/ex1.sentence_count, sum(ex2.verbs.values())/ex2.sentence_count, _type = 'verb')
        print(sum(ex1.verbs.values())/ex1.sentence_count, sum(ex2.verbs.values())/ex2.sentence_count)
        comp(ex1.word_ave,ex2.word_ave,_type = 'word count')
        print(ex1.word_ave,ex2.word_ave)
        comp(ex1.comma_count/ex1.sentence_count, ex2.comma_count/ex2.sentence_count, _type = 'comma')
        print(ex1.comma_count/ex1.sentence_count, ex2.comma_count/ex2.sentence_count)
        comp(ex1.dash_count/ex1.sentence_count, ex2.dash_count/ex2.sentence_count, _type = 'dash')
        print(ex1.dash_count/ex1.sentence_count, ex2.dash_count/ex2.sentence_count)
        
        
        
        
        
        
        
        
        print('\nAnalysis of verbs, sentence length, adverbs, adjectives, etc.\n' , comp_vals)
        print('\nAnalysis of N_grams:\n' , ngrams_vals)
            
        with open('test_author1.txt', 'w') as f:
            f.write('Comparing ' + txt1 +' and '+ txt2 +':\n')
            k = 0
            for i in n_gram:
                
                f.write('For N Gram = ' + str(i) + ' Value is ' + str(pred_lyst[k])+'.\n')
                k+=1
            f.write('\n')
        
    f.close()
if __name__ == '__main__':
    main()



