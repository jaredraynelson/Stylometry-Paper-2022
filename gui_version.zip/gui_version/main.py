from breezypythongui import EasyFrame
import main_driver as md
import os

welcome_message = '''
*** Welcome to my research project using Stylometry ***
*** to predict authorship. The main gist of this s- ***
*** imple program is for you as the user to compare ***
*** files which contain excerpts from books.  When  ***
*** the compute button is hit, the program will go  ***
*** through an algorithm to determine whether the   ***
*** writers of the files come from the same author. ***
'''

class GUI(EasyFrame):
  
    def __init__(self):
        self.output_message = ''
        EasyFrame.__init__(self, title="Stylometry Project",
                width=500, height=300, background='light grey')
        self.messageBox(title='Welcome!', message=welcome_message,
                            height = 10, width= 60)
        self.insert_files = self.addButton(text= "Enter files",
                    row = 0, column=0, columnspan=2, command=self.execute_files)
        self.show_results = self.addButton(text= "Show Prediction",
                    row = 0, column=2, columnspan=2, command=self.show_print_statement)

    def execute_files(self):
        self.output_message = ''
        prompterbox_1 = self.prompterBox(title='Enter the author\'s file name', fieldWidth=35)
        prompterbox_2 = self.prompterBox(title='Enter the second (test) file name', fieldWidth=45)
        prompterbox_1 = prompterbox_1.strip()
        prompterbox_2 = prompterbox_2.strip()
        
        both_os_paths_exist = False
        while not both_os_paths_exist:
            if os.path.isfile(prompterbox_1) and os.path.isfile(prompterbox_2):
                both_os_paths_exist = True
            else:
                if not os.path.isfile(prompterbox_1):
                    self.messageBox('Error in author file!', message='Make sure you entered the correct file name and don\'t'
                                    ' forget \'.txt\' at the end. (:', width=40)
                    prompterbox_1 = self.prompterBox(title='Enter the author\'s file name', fieldWidth=35)
                if not os.path.isfile(prompterbox_2):
                    self.messageBox('Error in second (test) file!', message="Make sure you entered the correct "+
                                    "file name and don\'t forget \'.txt\' at the end. (:", width=45)
                    prompterbox_2 = self.prompterBox(title='Enter the second (test) file name', fieldWidth=45)

        # EACH TIME IT RESETS THE VALUES HERE
        md.ngrams_vals = []
        md.comp_vals = []

        self.output_message = md.main_driver(prompterbox_1, prompterbox_2)
    
    def show_print_statement(self):
        self.messageBox(title='Final Decision', message=self.output_message, height=45, width=75)

def main():
    start = GUI()
    start.mainloop()


if __name__ == '__main__':
    main()