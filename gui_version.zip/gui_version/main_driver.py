import text_info as ti
import math

ngrams_vals = []
comp_vals = []



def comp(first, second, _type = 'noun'):
    output_message = ''
    comp_eqn = 100*(abs(first-second)/first)
    p_error_value = 100 - comp_eqn

    linear_value = (2/15) * p_error_value - (32/3)

    if abs(linear_value) > 3:
        if linear_value > 0:
            comp_vals.append(3)
        else:
            comp_vals.append(-3)
    else:
        comp_vals.append(linear_value)
    if linear_value > 0:
        output_message+=('\nThere is correlation with the ' + _type + ' usage!\n')
    else:
        output_message+=('\nThere is no correlation with the ' + _type + ' usage!\n')
        
    return output_message
        


    
def comp_ngrams(dict1, dict2, n):
    '''
    Takes in two dictionaries which come from text_info.py and will perform
    calculations to determine whether there is correlation in the n_grams of
    the words.
    '''
    cost = 18*math.exp(-2.35*(n-2))
    
    sum1 = sum(dict1.values())
    sum2 = sum(dict2.values())
    tot = 0
    # iterate through one dictionary and find the same string in the other.
    for i in dict1.keys():     
        if i in dict2.keys():
            x = dict1[i]
            y = dict2[i]
            # if equal, then sum up the two values.
            tot += x+y
    pred = 100*(tot/(sum1+sum2))
    print()
    print()
    print('Cost:', cost, '\nPred:',pred,'\nN-gram', n, '\nRate:', pred/cost)

    if pred > cost:
        ngrams_vals.append(4*pred/cost)
        return "Using NGrams, this data has correlation at rate " + str(pred/cost) + '.'

    else:
        ngrams_vals.append(-4*(1-(pred/cost)))
        return "Using NGrams, this data has correlation at rate " + str(1-pred/cost) + '.'
    



def pred_book(ng_vals, cmp_vals):
    output_message = ''
    # ng_vals = 1.5*ng_vals
    val = ng_vals + cmp_vals
    output_message += ('\n\n--------THE FINAL ASSESSMENT, THIS ALGORITHM PREDICTS--------') + '\n'
    if val>=0:
        output_message += ('*************************************************************') + '\n'
        output_message += ('*-------2ND  FILE  COMES  FROM  THE  ORIGINAL  AUTHOR.------*') + '\n'
        output_message += ('*************************************************************') + '\n'
    else:
        output_message += ('*************************************************************') + '\n'
        output_message += ('*-----2ND FILE DOES NOT COME FROM THE ORIGINIAL AUTHOR.-----*') + '\n'
        output_message += ('*************************************************************') + '\n'
    return output_message +'\n'
    


def main_driver(txt1, txt2):
    output_message = ''

    n_gram = [2,3,4]
    
    for i in n_gram:
        ex1 = ti.Read(txt1, i)
        ex2 = ti.Read(txt2, i)
        
        
        ex1_ngrams = ex1.n_grams
        sorted_ex1_ngrams = {}
        sorted_keys = sorted(ex1_ngrams, key=ex1_ngrams.get)  # [1, 3, 2]
    
        for w in sorted_keys:
            sorted_ex1_ngrams[w] = ex1_ngrams[w]
    
        
            
        ex2_ngrams = ex2.n_grams
        sorted_ex2_ngrams = {}
        sorted_keys = sorted(ex2_ngrams, key=ex2_ngrams.get)  # [1, 3, 2]
    
        for w in sorted_keys:
            sorted_ex2_ngrams[w] = ex2_ngrams[w]
    
        
    
        sorted_ex1_ngrams = {k: v / total for total in (sum(sorted_ex1_ngrams.values()),) for k, v in sorted_ex1_ngrams.items()}
        sorted_ex2_ngrams = {k: v / total for total in (sum(sorted_ex2_ngrams.values()),) for k, v in sorted_ex2_ngrams.items()}
    

        
        
        temp_message = comp_ngrams(sorted_ex1_ngrams, sorted_ex2_ngrams, i)
        
        output_message += temp_message + '\n'
        # pred_lyst.append(pred)
        
    output_message += comp(ex1.apos/ex1.sentence_count, ex2.apos/ex2.sentence_count, _type = 'apostrophe') + '\n'
    output_message+= str(ex1.apos/ex1.sentence_count) + ', ' + str(ex2.apos/ex2.sentence_count) + '\n'
    
    output_message += comp(sum(ex1.adjectives.values())/ex1.sentence_count, sum(ex2.adjectives.values())/ex2.sentence_count, _type = 'adjective')+ '\n'
    output_message+= str(sum(ex1.adjectives.values())/ex1.sentence_count) + ', ' + str(sum(ex2.adjectives.values())/ex2.sentence_count) + '\n'
    
    output_message += comp(sum(ex1.adverbs.values())/ex1.sentence_count, sum(ex2.adverbs.values())/ex2.sentence_count, _type = 'adverb')+ '\n'
    output_message+= str(sum(ex1.adverbs.values())/ex1.sentence_count) + ', ' + str(sum(ex2.adverbs.values())/ex2.sentence_count) + '\n'
    
    output_message += comp(sum(ex1.verbs.values())/ex1.sentence_count, sum(ex2.verbs.values())/ex2.sentence_count, _type = 'verb')+ '\n'
    output_message+= str(sum(ex1.verbs.values())/ex1.sentence_count) + ', ' + str(sum(ex2.verbs.values())/ex2.sentence_count) + '\n'
    
    output_message += comp(ex1.word_ave, ex2.word_ave, _type = 'word count') + '\n'
    output_message+= str(ex1.word_ave) + ', ' + str(ex2.word_ave) + '\n'
    
    output_message += comp(ex1.comma_count/ex1.sentence_count, ex2.comma_count/ex2.sentence_count, _type = 'comma') + '\n'
    output_message+= str(ex1.comma_count/ex1.sentence_count) + ', ' + str(ex2.comma_count/ex2.sentence_count) + '\n'
    
    output_message += comp(ex1.dash_count/ex1.sentence_count, ex2.dash_count/ex2.sentence_count, _type = 'dash') + '\n'
    output_message+= str(ex1.dash_count/ex1.sentence_count) + ', ' + str(ex2.dash_count/ex2.sentence_count) + '\n'
    

    
    cmp_vals = sum(comp_vals)
    ng_vals = sum(ngrams_vals)
    
    output_message += ('\nAnalysis of verbs, sentence length, adverbs, adjectives, etc ' + '= ' + str(cmp_vals)) + '\n'
    output_message += ('\nAnalysis of N_grams '+ '= ' + str(ng_vals)) + '\n'
        
    
    output_message += pred_book(ng_vals,cmp_vals)
    
    return output_message
    

    
    # with open('data.txt', 'a') as f:
    #     f.write('Comparing ' + txt1 +' and '+ txt2 +':\n')
    #     k = 0
    #     for i in n_gram:
            
    #         f.write('For N Gram = ' + str(i) + ' Value is ' + str(pred_lyst[k])+'.\n')
    #         k+=1
    #     f.write('\n')
    # f.close()
    

    # Compare the values to the cost function.
    # if  pred >= 1.5*cost:
    #     ngrams_vals.append(4)
    #     return pred, "Using NGrams, this data has very strong correlation."
    # elif pred >= 1.25*cost:
    #     ngrams_vals.append(3)
    #     return pred, "Using NGrams, this data has strong correlation."
    # elif pred >= cost:
    #     ngrams_vals.append(2)
    #     return pred, "Using NGrams, this data has correlation."
    # elif pred <= 0.5*cost:
    #     ngrams_vals.append(-3)
    #     return pred, "Using NGrams, this data has absolutely no correlation."    
    # elif pred <= 0.75*cost:
    #     ngrams_vals.append(-2)
    #     return pred, "Using NGrams, this data has no correlation."
    # else:
    #     ngrams_vals.append(-1)
    #     return pred, "Using NGrams, this data doesn\'t have enough correlation." 


    # pred_lyst = []
    # txt1 = 'kidnapped_train.txt'
    # txt2 = 'typee_test.txt'
